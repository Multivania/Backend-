#include "loginform.h"
#include "ui_loginform.h"
#include "mainwindow.h" // Добавляем заголовочный файл для вашего главного окна
#include <QMessageBox>

LoginForm::LoginForm(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::LoginForm)
{
    ui->setupUi(this);
}

LoginForm::~LoginForm()
{
    delete ui;
}

void LoginForm::on_pushButtonLogin_clicked()
{

    QString username = ui->lineEditUsername->text();
    QString password = ui->lineEditPassword->text();


    if (username == "admin" && password == "admin") {

         MainWindow *mainWindow = new MainWindow();
         mainWindow->show();


        this->close();
    } else {

        QMessageBox::critical(this, "Ошибка", "Неверный логин или пароль");
    }
}

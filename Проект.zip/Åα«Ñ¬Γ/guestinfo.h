#ifndef GUESTINFO_H
#define GUESTINFO_H

#include <QWidget>
#include <QDialog>
#include <QSqlQueryModel>
#include <QSqlTableModel>
namespace Ui {
class GuestInfo;
}

class GuestInfo : public QDialog
{
    Q_OBJECT

public:
    explicit GuestInfo(QWidget *parent = nullptr);
    ~GuestInfo();
    void readData();

private:
    Ui::GuestInfo *ui;
    QSqlTableModel* model;


};

#endif // GUESTINFO_H

#include "HistoryForm.h"
#include <QSqlTableModel>
#include <QTableView>
#include <QVBoxLayout>
#include <QHeaderView>
#include "ui_historyform.h"
#include <QDateTime>
#include <QCloseEvent>

HistoryForm::HistoryForm(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::HistoryForm)
{
    ui->setupUi(this);
    this->setFixedSize(550,500);
    this->setWindowTitle("History");

}

HistoryForm::~HistoryForm() {
    delete ui;  // Освобождение ресурсов
}
void HistoryForm::readData() {
    QSqlDatabase db = QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName("C:/Users/Иван/Desktop/Проект/OOP3.db");

    if (!db.open()) {
        // Обработка ошибки
        return;
    }

    QSqlQueryModel* model = new QSqlQueryModel(this);
    QSqlQuery query;


    query.prepare("SELECT Hotel_customer.*, Hotel_transaction.room AS 'Hotel Room Number' "
                  "FROM Hotel_customer "
                  "LEFT JOIN Hotel_transaction ON Hotel_customer.id = Hotel_transaction.customer_id");

    if (query.exec()) {
        model->setQuery(query);
        ui->tableView->setModel(model);

        // Настройка представления, если необходимо
        ui->tableView->setSelectionMode(QAbstractItemView::SingleSelection);
        ui->tableView->setSelectionBehavior(QAbstractItemView::SelectRows);
        ui->tableView->resizeColumnsToContents();
        ui->tableView->setEditTriggers(QAbstractItemView::NoEditTriggers);
    } else {

    }

    db.close();
};

void HistoryForm::closeEvent(QCloseEvent *event) {
    if (model) {
        delete model; // Освобождаем ресурсы модели, если она была создана
        model = nullptr;
    }
    event->accept();
}






void HistoryForm::on_closeButton_clicked()
{
close();
}


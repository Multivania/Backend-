//   #include "checkoutdialog.h"
   #include "ui_checkoutdialog.h"
  #include <QDebug>
#include "checkoutdialog.h"
#include "hotel.h"
checkoutdialog::checkoutdialog(QWidget *parent) :
       QDialog(parent),
       ui(new Ui::checkoutdialog)
   {
       ui->setupUi(this);

       // Отключение кнопки Checkout при старте
       ui->btnCheckout->setEnabled(false);
   }

   checkoutdialog::~checkoutdialog()
   {
       delete ui;
   }

   void checkoutdialog::readData()
   {
       std::vector<int> rooms = Hotel::getInstance()->getRoomList("n");
           this->ui->comboBox->clear();

           char flag = 0;
           for (std::vector<int>::iterator it = rooms.begin(); it != rooms.end(); it++)
           {
               this->ui->comboBox->addItem(QString::number(*it));
               flag = 1;
           }

           if (flag == 1)
               this->ui->btnCheckout->setEnabled(true);


           ui->dateOut->setDate(QDate::currentDate());
   }

   void checkoutdialog::on_btnCancel_clicked()
   {
       this->show();
   }

   void checkoutdialog::on_btnCheckout_clicked()
   {
       int roomno = ui->comboBox->currentText().toInt();

       if (roomno < 1)
       {
           QMessageBox::information(
               this,
               tr("Ошибка!"),
               tr("Все номера свободны."));
           return;
       }


       QString checkoutDate = ui->dateOut->date().toString("yyyy-MM-dd");

       qDebug() << "Selected Checkout Date: " << checkoutDate;

       int ret = Hotel::getInstance()->CheckOut(roomno, checkoutDate);

       QString msg = "";
       ret == 0 ? msg = "Success!" : msg = "Failure!";

       this->hide();

       if (ret == 0)
       {
           QMessageBox::information(
               this,
               tr("Успешно!"),
               tr("Номер был успешно освобожден"));
       }
   }

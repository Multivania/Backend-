    #include "mainwindow.h"
    #include "ui_mainwindow.h"
    #include <QListWidget>
    #include <QDebug>
    #include "HistoryForm.h"


        MainWindow::MainWindow(QWidget *parent) :
            QMainWindow(parent),
            ui(new Ui::MainWindow)
        {
            ui->setupUi(this);
            this->setFixedSize(800, 550);

            ptrRoomAvailableDlg = new RoomAvailableDialog(this);
            ptrCheckOutDlg = new checkoutdialog(this);
            ptrRoomBookingDlg = new BookRoomDialog(this);
            ptrTransaction = new transaction(this);
            ui->btnCheckAvailability->setText("Свободные");
            ui->btnRoomBooking->setText("Бронирование");
            ui->btnRoomCheckout->setText("Выезд");
            ui->bntTransaction->setText("Транзакции");
            ui->btnShowHistory->setText("История"); // Добавляем кнопку для отображения истории

            this->setWindowTitle("Booking Hotel");
            guestInfoDialog = new GuestInfo(this);
         historyForm = new HistoryForm(this);


              connect(ui->btnShowHistory, &QPushButton::clicked, this, &MainWindow::showHistory); // Соединяем сигнал и слот
         connect(ui->GuesInfo, &QPushButton::clicked, this, &MainWindow::on_GuesInfo_clicked);

        }

    MainWindow::~MainWindow()
    {
        qDebug() << "MainWindow: Deleting";
        delete ui;
        delete ptrRoomBookingDlg;
        delete ptrCheckOutDlg;
        delete ptrRoomAvailableDlg;
        delete ptrTransaction;
         delete historyForm;
    }

    void MainWindow::on_btnRoomBooking_clicked()
    {
        qDebug() << this->metaObject()->className() << ": In Room Booking";
        ptrRoomBookingDlg->readData();
        ptrRoomBookingDlg->show();

        if (ptrRoomBookingDlg->isVisible())
            qDebug() << "New Window is visible";
        else
            qDebug() << "New Window is not visible";
        // BookRoom();
    }

    void MainWindow::on_btnRoomCheckout_clicked()
    {
        qDebug() << this->metaObject()->className() << ": In Room Checkout";


        checkoutdialog *ptrCheckOutDlg = new checkoutdialog(this);


        ptrCheckOutDlg->readData();
        ptrCheckOutDlg->exec(); // Вместо show()
    }

    void MainWindow::on_btnCheckAvailability_clicked()
    {
        qDebug() << this->metaObject()->className() << ": In Check Availability";
        ptrRoomAvailableDlg->readData();
        ptrRoomAvailableDlg->show();
    }

    void MainWindow::on_bntTransaction_clicked()
    {
        ptrTransaction->readData();
        ptrTransaction->show();
    }

    void MainWindow::showHistory()
    {

        historyForm->show();
    }


    void MainWindow::on_btnShowHistory_clicked()
    {   historyForm->readData();
        showHistory();

    }


    void MainWindow::on_GuesInfo_clicked()
    {
        if (guestInfoDialog) {
            guestInfoDialog->readData();
            guestInfoDialog->show();
        }
    }





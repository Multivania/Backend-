#ifndef CHECKOUTDIALOG_H
#define CHECKOUTDIALOG_H

#include <QDialog>
#include <QDebug>
#include <QSqlQuery>
#include <QFile>
#include <QSqlDatabase>
#include <QSqlError>
//#include "hotel.h"
#include <QMessageBox>
#include <QDateEdit>
namespace Ui {
class checkoutdialog;
}

class checkoutdialog : public QDialog
{
    Q_OBJECT

public:
    explicit checkoutdialog(QWidget *parent = nullptr);
    ~checkoutdialog();
    void readData();

private slots:
    void on_btnCancel_clicked();
    void on_btnCheckout_clicked();

private:
    Ui::checkoutdialog *ui;
    QDateEdit *dateOut;
     QString checkoutDate;

};

#endif // CHECKOUTDIALOG_H

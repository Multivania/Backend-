#include "roomavailabledialog.h"
#include "ui_roomavailabledialog.h"
#include <QDebug>

RoomAvailableDialog::RoomAvailableDialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::RoomAvailableDialog)
{
    ui->setupUi(this);
    this->setFixedSize(380,300);
    this->setWindowTitle("Available room");
    qDebug()<<"In RoomAvailableDialog()";
    //this->setWindowIcon(QIcon(":/available.jpg"));


}

void RoomAvailableDialog::readData()
{
    qDebug()<<"in readData()";

    std::vector<int>rooms = Hotel::getInstance()->getRoomList("Y");
    ui->lblinfo->setStyleSheet("QLabel { background-color : grey; color : aqua; }");

    std::vector<int>temprooms =  {101, 102, 103, 104, 201, 202, 203, 204, 301, 302,303,304};


    for(std::vector<int>::iterator it = temprooms.begin(); it!=temprooms.end(); it++ )
    {

        QString lblname = "lbl" + QString::number(*it);
        QLabel * ptr = this->findChild<QLabel*>(lblname);

        if(ptr)
        {
            ptr->setStyleSheet("QLabel { background-color : lightgrey; color : aqua; }");
        }

    }

    for(std::vector<int>::iterator it = rooms.begin(); it!=rooms.end(); it++ )
    {

        QString lblname = "lbl" + QString::number(*it);
        QLabel * ptr = this->findChild<QLabel*>(lblname);

        if(ptr)
        {

            ptr->setStyleSheet("QLabel { background-color : grey; color : aqua; }");
        }

    }
}

RoomAvailableDialog::~RoomAvailableDialog()
{
    qDebug()<<"Deleting RoomAvailableDialog";
    delete ui;
}

    QString RoomAvailableDialog::groupBox()const{
            return ui->lbl101->text();
            return ui->lbl102->text();
            return ui->lbl103->text();
            return ui->lbl104->text();
            return ui->lbl201->text();
            return ui->lbl202->text();
            return ui->lbl203->text();
            return ui->lbl204->text();
            return ui->lbl301->text();
            return ui->lbl302->text();
            return ui->lbl303->text();
            return ui->lbl304->text();



    }
void RoomAvailableDialog::on_pushButton_clicked()
{
    this->hide();
}

#ifndef HISTORYFORM_H
#define HISTORYFORM_H

#include <QDialog>
#include "ui_historyform.h"
#include <QSqlQuery>
#include <QSqlError>
#include <QDebug>
#include <QFile>
#include <QSqlTableModel>

namespace Ui {
class HistoryForm;
}

class HistoryForm : public QDialog {
    Q_OBJECT
protected:
    void closeEvent(QCloseEvent *event) override;

public:
    explicit HistoryForm(QWidget *parent = nullptr);
    ~HistoryForm();
     void readData();
      QSqlTableModel *model;

 private slots:
     void on_closeButton_clicked();

 private:
    Ui::HistoryForm *ui;

};

#endif // HISTORYFORM_H


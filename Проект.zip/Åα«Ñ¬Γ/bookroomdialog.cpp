
#include "bookroomdialog.h"
#include "ui_bookroomdialog.h"
#include <QStandardItemModel>

BookRoomDialog::BookRoomDialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::BookRoomDialog)
{
    ui->setupUi(this);
    this->setWindowTitle("Booking a room");
    this->setFixedSize(500, 500);
    ui->btnCancel->setText("Закрыть");
    ui->btnSubmit->setText("Снять");

}

void BookRoomDialog::readData()
{
    qDebug() << "BookRoomDialog:readData";
    std::vector<int> rooms = Hotel::getInstance()->getRoomList("Y");
    this->ui->cmbRoomList->clear();

    for (std::vector<int>::iterator it = rooms.begin(); it != rooms.end(); it++)
    {
        this->ui->cmbRoomList->addItem(QString::number(*it));
    }
}

BookRoomDialog::~BookRoomDialog()
{
    delete ui;
}

void BookRoomDialog::on_btnCancel_clicked()
{
    this->hide();
}

void BookRoomDialog::on_btnSubmit_clicked()
{
    int roomno = ui->cmbRoomList->currentText().toInt();
    QString name = ui->txtName->text();
    QString contactno = ui->txtContactNumber->text();
    QString data_in = ui->dateIn->date().toString("yyyy-MM-dd");
    QString data_out = ui->dateOut->date().toString("yyyy-MM-dd");
    QString govtid = ui->txtIdProof->text();

    if (name.isEmpty() || govtid.isEmpty()) {
        QMessageBox::information(
            this,
            tr("Ошибка!"),
            tr("Имя и удостоверение личности должны быть заполнены."));
        return;
    }

    if (roomno < 1)
    {
        QMessageBox::information(
            this,
            tr("Ошибка!"),
            tr("Все номера заняты."));
        return;
    }




    QDate checkinDate = QDate::currentDate();
    QDate checkoutDate = ui->dateIn->date();
    int daysDifference = checkinDate.daysTo(checkoutDate);



    int ret = Hotel::getInstance()->BookRoom(roomno, name, contactno, govtid, data_in, data_out);
    if (ret == 0) {
        QMessageBox::information(
            this,
            tr("Успешно!"),
            tr("Регистрация прошла успешно!"));
    } else {
        QMessageBox::information(
            this,
            tr("Ошибка!"),
            tr("Возникла проблема при регистрации."));
    }

    this->hide();
    QString msg = "";
    ret == 0 ? msg = "Success!" : msg = "Failure!";

    this->hide();

}


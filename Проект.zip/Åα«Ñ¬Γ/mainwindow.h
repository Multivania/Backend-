#ifndef MAINWINDOW_H
#define MAINWINDOW_H
#include "guestinfo.h"
#include <QMainWindow>
#include "bookroomdialog.h"
#include "checkoutdialog.h"
#include "roomavailabledialog.h"
#include "transaction.h"
#include "historyform.h"

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

private:
    RoomAvailableDialog * ptrRoomAvailableDlg;
    checkoutdialog * ptrCheckOutDlg;
    BookRoomDialog * ptrRoomBookingDlg;
    transaction * ptrTransaction;
    HistoryForm *historyForm;
  GuestInfo *guestInfoDialog;



public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow();
    void clearTransactionList();

private slots:
    void on_btnRoomBooking_clicked();
    void on_btnRoomCheckout_clicked();
    void on_btnCheckAvailability_clicked();
    void on_bntTransaction_clicked();
    void showHistory();


    void on_btnShowHistory_clicked();

    void on_GuesInfo_clicked();



private:
    Ui::MainWindow *ui;
};

#endif // MAINWINDOW_H

#include "hotel.h"
#include "QDebug"

Hotel* Hotel::instance = nullptr;

int Hotel::CheckOut(int roomno, const QString &checkoutDate)
{
    qDebug() << "Checking out room number: " << roomno;

    QSqlDatabase Database = QSqlDatabase::addDatabase("QSQLITE", "Data");
    Database.setDatabaseName("C:/Users/Иван/Desktop/Проект/OOP3.db");

    if (QFile::exists("C:/Users/Иван/Desktop/Проект/OOP3.db"))
        qDebug() << "DB file exists";
    else
        qDebug() << "DB file doesn't exist";

    if (!Database.open()) {
        qDebug() << Database.lastError().text();
        return -1;
    } else {
        qDebug() << "Database loaded successfully!";
    }

    QSqlQuery query(Database);


    query.prepare("UPDATE Hotel_room SET available = 'Y' WHERE number = :roomno");
    query.bindValue(":roomno", roomno);

    if (!query.exec()) {
        qDebug() << query.lastError().text() << query.lastQuery();
        return -1;
    }


    query.clear();

    query.prepare("UPDATE Hotel_customer SET is_checked_in = 0, data_out = :checkout WHERE id IN (SELECT customer_id FROM Hotel_transaction WHERE room = :room AND is_checked_in = 1)");
    query.bindValue(":room", roomno);  // roomno - это номер комнаты, из которой выходит клиент
    query.bindValue(":checkout", checkoutDate); // checkoutDate - дата выезда клиента



    if (!query.exec()) {
        qDebug() << query.lastError().text() << query.lastQuery();
        return -1;
    }

    Database.close();
    return 0;
}

// int Hotel::CheckOut(int roomno, const QString &checkoutDate) {
//     qDebug() << "Checking out room number: " << roomno;

//     QSqlDatabase Database = QSqlDatabase::addDatabase("QSQLITE", "Data");
//     Database.setDatabaseName("C:/UsersИван/Desktop/Проект/OOP3.db");

//     if (QFile::exists("C:/Users/Иван/Desktop/Проект/OOP3.db"))
//         qDebug() << "DB file exists";
//     else
//         qDebug() << "DB file doesn't exist";

//     if (!Database.open()) {
//         qDebug() << Database.lastError().text();
//         return -1;
//     } else {
//         qDebug() << "Database loaded successfully!";
//     }

//     QSqlQuery query(Database);

//     // Обновление статуса комнаты в таблице "Hotel_room"
//     query.prepare("UPDATE Hotel_room SET available = 'Y' WHERE number = :roomno");
//     query.bindValue(":roomno", roomno);

//     if (!query.exec()) {
//         qDebug() << query.lastError().text() << query.lastQuery();
//         return -1;
//     }

//     // Обновление статуса клиента на выезд (is_checked_in = 0)
//     query.clear();
//     query.prepare("UPDATE Hotel_customer SET is_checked_in = 0 WHERE id = (SELECT customer_id FROM Hotel_transaction WHERE room = :room)");
//     query.bindValue(":room", roomno);

//     if (!query.exec()) {
//         qDebug() << query.lastError().text() << query.lastQuery();
//         return -1;
//     }

//     Database.close();
//     return 0;
// }















int Hotel::BookRoom(int roomno, QString name, QString contactno, QString govtid, QString data_in, QString data_out)
{
    qDebug() << "in BookRoom for room no : " << roomno;


    QSqlDatabase Database = QSqlDatabase::addDatabase("QSQLITE", "Data");
    Database.setDatabaseName("C:/Users/Иван/Desktop/Проект/OOP3.db");
    if (QFile::exists("C:/Users/Иван/Desktop/Проект/OOP3.db"))
        qDebug() << "DB file exists";
    else
        qDebug() << "DB file doesn't exist";

    if (!Database.open())
        qDebug() << Database.lastError().text();
    else
        qDebug() << "Database loaded successfully!";

    QSqlQuery query(Database);


    query.prepare("update Hotel_room set available ='n' where number='" + QString::number(roomno) + "'");
    if (!query.exec())
        qDebug() << query.lastError().text() << query.lastQuery();
    else
        qDebug() << "Update was successful " << query.lastQuery();


    query.clear();
    query.prepare("INSERT INTO Hotel_customer (name, mobileno, govtid, data_in, data_out, is_checked_in) VALUES (:name, :contactno, :govtid, :data_in, :data_out, 1)");
    query.bindValue(":name", name);
    query.bindValue(":contactno", contactno);
    query.bindValue(":govtid", govtid);
    query.bindValue(":data_in", data_in); // Дата въезда клиента
    query.bindValue(":data_out", data_out); // Дата выезда клиента

    if (!query.exec()) {
        qDebug() << query.lastError().text() << query.lastQuery();
    } else {
        qDebug() << "Insert into Hotel_customer was successful";
        QVariant varCustomerId = query.lastInsertId();
        QString customer_id = varCustomerId.toString();
        qDebug() << "Last Inserted Customer ID is: " << customer_id;


        query.clear();
        query.prepare("INSERT INTO Hotel_transaction (room, customer_id) VALUES (:roomno, :customer_id)");
        query.bindValue(":roomno", roomno);
        query.bindValue(":customer_id", customer_id.toInt()); // Здесь предполагается, что customer_id - это целое число

        if (!query.exec()) {
            qDebug() << query.lastError().text() << query.lastQuery();
        } else {
            qDebug() << "Insert into Hotel_transaction was successful";
            qDebug() << "Last Inserted Transaction ID is: " << query.lastInsertId().toString();
        }
    }


    Database.close();
    // getRoomList();
    return 0;
}


std::vector<int> Hotel::getRoomList(QString flag = "Y")
{
        std::vector<int> rooms;
        //if(availableRooms.empty())
        QSqlDatabase Database = QSqlDatabase::addDatabase("QSQLITE", "Data");
        Database.setDatabaseName("C:/Users/Иван/Desktop/Проект/OOP3.db");
        if(QFile::exists("C:/Users/Иван/Desktop/Проект/OOP3.db"))
            qDebug() << "DB file exist";
        else
           qDebug() << "DB file doesn't exists";

        if (!Database.open())
            qDebug() << Database.lastError().text();
        else
            qDebug() << "Database loaded successfull!";

        QSqlQuery query(Database);
        query.prepare("select number from Hotel_room where available = '" + flag + "'");

        if(!query.exec())
            qDebug() << query.lastError().text() << query.lastQuery();
        else
            qDebug() << "Fetch was successful";

        while(query.next())
        {
            QString record = query.value(0).toString();
            rooms.push_back(record.toInt());
            qDebug()<<"Line is : "<<record;
        }

        Database.close();
        return rooms;
}

Hotel *Hotel::getInstance()
{
    if(instance == nullptr)
        instance = new Hotel();
    return instance;
}

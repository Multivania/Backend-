#include "guestinfo.h"
#include "ui_guestinfo.h"
#include <QSqlQuery>
#include <QSqlError>
#include <QDebug>
#include <QSqlTableModel>
GuestInfo::GuestInfo(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::GuestInfo)
{
    ui->setupUi(this);
    model = new QSqlTableModel(this);


}

GuestInfo::~GuestInfo()
{
    delete ui;
}

void GuestInfo::readData()
{
    QSqlDatabase db = QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName("C:/Users/Иван/Desktop/Проект/OOP3.db");

    if (!db.open()) {
        qDebug() << "Database error: " << db.lastError().text();
        return;
    }

    QSqlQueryModel* model = new QSqlQueryModel(this);
    QSqlQuery query;

    // Создаем SQL-запрос, который объединяет информацию из таблиц Hotel_customer и Hotel_transaction
    query.prepare("SELECT Hotel_customer.*, Hotel_transaction.room AS 'Hotel Room Number' "
                  "FROM Hotel_customer "
                  "LEFT JOIN Hotel_transaction ON Hotel_customer.id = Hotel_transaction.customer_id "
                  "WHERE Hotel_customer.is_checked_in = 1");

    if (query.exec()) {
        model->setQuery(query);
        ui->tableView->setModel(model);

        // Настройка представления, если необходимо
        ui->tableView->setSelectionMode(QAbstractItemView::SingleSelection);
        ui->tableView->setSelectionBehavior(QAbstractItemView::SelectRows);
        ui->tableView->resizeColumnsToContents();
        ui->tableView->setEditTriggers(QAbstractItemView::NoEditTriggers);
    }
    db.close();


}
